// Windows specific auto configuration preference defaults
platform.value = "windows";
